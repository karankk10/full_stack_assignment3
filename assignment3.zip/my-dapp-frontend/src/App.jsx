import "./App.css";
import CurrencySelector from "./components/CurrencySelector";
import contractABI from "./contracts/currency.json";


const contractAddress = "0x9CA0F1e6b03c7496F2F4C76F66dB3a74dA456AD4";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        
        <CurrencySelector
          contractAddress={contractAddress}
          contractABI={contractABI}
        />
      </header>
    </div>
  );
}

export default App;
