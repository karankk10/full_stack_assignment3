require("@nomiclabs/hardhat-waffle");
require('dotenv').config();

const { SEPOLIA_URL, PRIVATE_KEY } = process.env;

module.exports = {
  solidity: "0.8.22",
  networks: {
    hardhat: {
      chainId: 1337
    },
    sepolia: {
      url: "https://eth-sepolia.g.alchemy.com/v2/DkMAngseb9jqCG2fAqiRyL3sDJtNwpIo",
      accounts: ["0x811cbc134e6042812662b8649a3154b68fe87e2158c7732a2659c0202a0d8cbd"]
    }
  }
};
